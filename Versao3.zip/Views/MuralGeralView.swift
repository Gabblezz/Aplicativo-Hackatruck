import SwiftUI
import Foundation
import Combine

import SwiftUI

struct MuralGeralView: View {
    let userRole: String
    let userId: String
    let userName: String
    let userCourse: String
    
    @State private var postagens: [PostagemMural] = []
    @State private var showingNewPost = false
    @State private var loading = false
    @State private var errorMessage = ""
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                Group {
                    if loading {
                        ProgressView("Carregando mural...")
                    } else if postagens.isEmpty {
                        EmptyStateView(
                            icon: "megaphone",
                            title: "Nenhuma postagem",
                            message: "Seja o primeiro a publicar um aviso."
                        )
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 14) {
                                ForEach(postagens) { postagem in
                                    PostCard(postagem: postagem)
                                }
                            }
                            .padding(.horizontal)
                            .padding(.top, 10)
                            .padding(.bottom, 80) // Espaço para o botão flutuante não cobrir o último post
                        }
                        .background(Color(.systemGroupedBackground))
                        .refreshable { await carregar() }
                    }
                }
                
                // Botão Flutuante (FAB) do Teams no canto inferior direito
                Button {
                    showingNewPost = true
                } label: {
                    Image(systemName: "square.and.pencil")
                        .font(.title2.bold())
                        .foregroundStyle(.white)
                        .frame(width: 56, height: 56)
                        .background(Color.purple, in: Circle())
                        .shadow(color: Color.purple.opacity(0.4), radius: 8, x: 0, y: 4)
                }
                .padding(.trailing, 20)
                .padding(.bottom, 20)
            }
            .navigationTitle("Mural Geral")
            .sheet(isPresented: $showingNewPost) {
                NewPostView(
                    userRole: userRole,
                    userId: userId,
                    userName: userName,
                    userCourse: userCourse
                ) {
                    Task { await carregar() }
                }
            }
            .task { await carregar() }
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                Button("OK") { errorMessage = "" }
            } message: { Text(errorMessage) }
        }
    }
    
    private func carregar() async {
        loading = true
        defer { loading = false }
        
        if APIConfig.usarDadosLocais {
            postagens = []
            return
        }
        
        do {
            postagens = try await APIService.shared.buscarDocumentos().compactMap {
                if case .postagem(let postagem) = $0 { return postagem }
                return nil
            }
            .sorted { $0.timestamp > $1.timestamp }
            errorMessage = ""
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
