import SwiftUI
import Foundation
import Combine



struct EditarAnuncioView: View {
    
    @Environment(\.dismiss) private var dismiss
    
    let anuncio: Anuncio
    
    let onSaved: () -> Void
    
    
    
    @State private var type = ""
    
    @State private var title = ""
    
    @State private var description = ""
    
    @State private var destino = "@geral"
    
    @State private var cursoEscolhido = ""
    
    @State private var saving = false
    
    @State private var errorMessage = ""
    
    
    
    private let categorias = ["Material", "Residencia", "Servico", "Outro"]
    
    private let cursos = Cursos.lista
    
    
    
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Picker("Categoria", selection: $type) {
                    
                    ForEach(categorias, id: \.self) { Text($0) }
                    
                }
                
                
                
                Section("Destino do anuncio") {
                    
                    Picker("Notificar", selection: $destino) {
                        
                        Text("Todos (@geral)").tag("@geral")
                        
                        Text("Curso especifico (@curso)").tag("@curso")
                        
                    }
                    
                    .pickerStyle(.segmented)
                    
                    
                    
                    if destino == "@curso" {
                        
                        Picker("Escolha o curso", selection: $cursoEscolhido) {
                            
                            Text("Selecione um curso").tag("")
                            
                            ForEach(cursos, id: \.self) { Text($0).tag($0) }
                            
                        }
                        
                    }
                    
                }
                
                
                
                Section("Detalhes") {
                    
                    TextField("Titulo", text: $title)
                    
                    TextEditor(text: $description)
                    
                        .frame(minHeight: 120)
                    
                }
                
                
                
                Button {
                    
                    Task { await salvar() }
                    
                } label: {
                    
                    HStack {
                        
                        Spacer()
                        
                        if saving { ProgressView() } else { Text("Salvar").bold() }
                        
                        Spacer()
                        
                    }
                    
                }
                
                .disabled(!podeSalvar || saving)
                
            }
            
            .navigationTitle("Editar anuncio")
            
            .toolbar {
                
                ToolbarItem(placement: .cancellationAction) {
                    
                    Button("Cancelar") { dismiss() }
                    
                }
                
            }
            
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                
                Button("OK") { errorMessage = "" }
                
            } message: { Text(errorMessage) }
            
                .onAppear {
                    
                    type = anuncio.anuncioType
                    
                    title = anuncio.title
                    
                    description = anuncio.description
                    
                    destino = anuncio.destino ?? "@geral"
                    
                    cursoEscolhido = anuncio.cursoDestino ?? ""
                    
                    if destino == "@curso" && cursoEscolhido.isEmpty {
                        
                        cursoEscolhido = anuncio.course
                        
                    }
                    
                }
            
        }
        
    }
    
    
    
    private var podeSalvar: Bool {
        
        if title.isEmpty || description.isEmpty { return false }
        
        if destino == "@curso" && cursoEscolhido.isEmpty { return false }
        
        return true
        
    }
    
    
    
    private func salvar() async {
        
        saving = true
        
        defer { saving = false }
        
        
        
        let cursoFinal = destino == "@geral" ? "Geral / Todos" : cursoEscolhido
        
        var atualizado = anuncio
        
        atualizado.anuncioType = type
        
        atualizado.title = title
        
        atualizado.description = description
        
        atualizado.course = cursoFinal
        
        atualizado.destino = destino
        
        atualizado.cursoDestino = destino == "@geral" ? nil : cursoEscolhido
        
        do {
            
            try await APIService.shared.atualizar(atualizado)
            
            onSaved()
            
            dismiss()
            
        } catch {
            
            errorMessage = error.localizedDescription
            
        }
        
    }
    
}

