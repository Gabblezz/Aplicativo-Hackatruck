import SwiftUI
import Foundation
import Combine

struct NewPostView: View {
    
    @Environment(\.dismiss) private var dismiss
    
    let userRole: String
    
    let userId: String
    
    let userName: String
    
    let userCourse: String
    
    let onSaved: () -> Void
    
    
    
    @State private var destino = "@geral"
    
    @State private var cursoEscolhido = ""
    
    @State private var texto = ""
    
    @State private var saving = false
    
    @State private var errorMessage = ""
    
    
    
    private let cursos = Cursos.lista
    
    
    
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Section("Destino") {
                    
                    Picker("Notificar", selection: $destino) {
                        
                        Text("Todos (@geral)").tag("@geral")
                        
                        Text("Curso especifico (@curso)").tag("@curso")
                        
                    }
                    
                    .pickerStyle(.segmented)
                    
                    
                    
                    if destino == "@curso" {
                        
                        Picker("Escolha o curso", selection: $cursoEscolhido) {
                            
                            Text("Selecione um curso").tag("")
                            
                            ForEach(cursos, id: \.self) { Text($0).tag($0) }
                            
                        }
                        
                    }
                    
                }
                
                
                
                Section("Mensagem") {
                    
                    TextEditor(text: $texto)
                    
                        .frame(minHeight: 140)
                    
                }
                
                
                
                Button {
                    
                    Task { await publicar() }
                    
                } label: {
                    
                    HStack {
                        
                        Spacer()
                        
                        if saving { ProgressView() } else { Text("Publicar").bold() }
                        
                        Spacer()
                        
                    }
                    
                }
                
                .disabled(!podeSalvar || saving)
                
            }
            
            .navigationTitle("Nova postagem")
            
            .toolbar {
                
                ToolbarItem(placement: .cancellationAction) {
                    
                    Button("Cancelar") { dismiss() }
                    
                }
                
            }
            
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                
                Button("OK") { errorMessage = "" }
                
            } message: { Text(errorMessage) }
            
        }
        
    }
    
    
    
    private var podeSalvar: Bool {
        
        if texto.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return false }
        
        if destino == "@curso" && cursoEscolhido.isEmpty { return false }
        
        return true
        
    }
    
    
    
    private func publicar() async {
        
        saving = true
        
        defer { saving = false }
        
        
        
        let cursoFinal: String? = destino == "@geral" ? nil : cursoEscolhido
        
        let mencao = destino == "@geral" ? "@geral" : "@\(cursoEscolhido)"
        
        
        
        let postagem = PostagemMural(
            
            id: nil,
            
            rev: nil,
            
            tipo: "postagem",
            
            authorId: userId.isEmpty ? nil : userId,
            
            authorName: userName,
            
            authorRole: userRole.capitalized,
            
            authorCourse: userCourse,
            
            text: "\(mencao) \(texto.trimmingCharacters(in: .whitespacesAndNewlines))",
            
            timestamp: ISO8601DateFormatter().string(from: Date()),
            
            destino: destino,
            
            cursoDestino: cursoFinal
            
        )
        
        
        
        do {
            
            try await APIService.shared.criar(postagem)
            
            onSaved()
            
            dismiss()
            
        } catch {
            
            errorMessage = error.localizedDescription
            
        }
        
    }
    
}



