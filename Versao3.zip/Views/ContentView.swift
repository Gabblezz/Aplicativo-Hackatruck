import SwiftUI
import Foundation
import Combine

struct ContentView: View {
    
    @AppStorage("userRole") private var userRole = ""
    
    @AppStorage("isProfileCompleted") private var isProfileCompleted = false
    
    @AppStorage("userId") private var userId = ""
    
    @AppStorage("userName") private var userName = ""
    
    @AppStorage("userCourse") private var userCourse = ""
    
    @AppStorage("receberGeral") private var receberGeral = true
    
    @AppStorage("receberCursos") private var receberCursos = true
    
    
    
    var body: some View {
        
        Group {
            
            if userRole.isEmpty {
                
                RoleSelectionView(userRole: $userRole)
                
            } else if !isProfileCompleted {
                
                CompleteInfoView(
                    
                    userRole: $userRole,
                    
                    isProfileCompleted: $isProfileCompleted,
                    
                    userId: $userId,
                    
                    userName: $userName,
                    
                    userCourse: $userCourse,
                    
                    receberGeral: $receberGeral,
                    
                    receberCursos: $receberCursos
                    
                )
                
            } else {
                
                MainDashboardView(
                    
                    userRole: $userRole,
                    
                    isProfileCompleted: $isProfileCompleted,
                    
                    userId: $userId,
                    
                    userName: $userName,
                    
                    userCourse: $userCourse,
                    
                    receberGeral: $receberGeral,
                    
                    receberCursos: $receberCursos
                    
                )
                
            }
            
        }
        
    }
    
}
