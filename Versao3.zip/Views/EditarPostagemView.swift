import SwiftUI
import Foundation
import Combine


struct EditarPostagemView: View {
    
    @Environment(\.dismiss) private var dismiss
    
    let postagem: PostagemMural
    
    let onSaved: () -> Void
    
    
    
    @State private var texto = ""
    
    @State private var destino = "@geral"
    
    @State private var cursoEscolhido = ""
    
    @State private var saving = false
    
    @State private var errorMessage = ""
    
    
    
    private let cursos = Cursos.lista
    
    
    
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Section("Destino") {
                    
                    Picker("Notificar", selection: $destino) {
                        
                        Text("Todos (@geral)").tag("@geral")
                        
                        Text("Curso especifico (@curso)").tag("@curso")
                        
                    }
                    
                    .pickerStyle(.segmented)
                    
                    
                    
                    if destino == "@curso" {
                        
                        Picker("Escolha o curso", selection: $cursoEscolhido) {
                            
                            Text("Selecione um curso").tag("")
                            
                            ForEach(cursos, id: \.self) { Text($0).tag($0) }
                            
                        }
                        
                    }
                    
                }
                
                
                
                Section("Mensagem") {
                    
                    TextEditor(text: $texto).frame(minHeight: 140)
                    
                }
                
                
                
                Button {
                    
                    Task { await salvar() }
                    
                } label: {
                    
                    HStack {
                        
                        Spacer()
                        
                        if saving { ProgressView() } else { Text("Salvar").bold() }
                        
                        Spacer()
                        
                    }
                    
                }
                
                .disabled(!podeSalvar || saving)
                
            }
            
            .navigationTitle("Editar publicacao")
            
            .toolbar {
                
                ToolbarItem(placement: .cancellationAction) {
                    
                    Button("Cancelar") { dismiss() }
                    
                }
                
            }
            
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                
                Button("OK") { errorMessage = "" }
                
            } message: { Text(errorMessage) }
            
                .onAppear {
                    
                    texto = postagem.text
                    
                    destino = postagem.destino ?? "@geral"
                    
                    cursoEscolhido = postagem.cursoDestino ?? ""
                    
                }
            
        }
        
    }
    
    
    
    private var podeSalvar: Bool {
        
        if texto.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return false }
        
        if destino == "@curso" && cursoEscolhido.isEmpty { return false }
        
        return true
        
    }
    
    
    
    private func salvar() async {
        
        saving = true
        
        defer { saving = false }
        
        
        
        var atualizada = postagem
        
        let mencao = destino == "@geral" ? "@geral" : "@\(cursoEscolhido)"
        
        let textoLimpo = texto.trimmingCharacters(in: .whitespacesAndNewlines)
        
        let textoFinal = textoLimpo.hasPrefix("@") ? textoLimpo : "\(mencao) \(textoLimpo)"
        
        
        
        atualizada.text = textoFinal
        
        atualizada.destino = destino
        
        atualizada.cursoDestino = destino == "@geral" ? nil : cursoEscolhido
        
        
        
        do {
            
            try await APIService.shared.atualizar(atualizada)
            
            onSaved()
            
            dismiss()
            
        } catch {
            
            errorMessage = error.localizedDescription
            
        }
        
    }
    
}


