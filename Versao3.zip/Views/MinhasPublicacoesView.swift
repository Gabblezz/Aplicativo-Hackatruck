import SwiftUI
import Foundation
import Combine

struct MinhasPublicacoesView: View {
    
    @Environment(\.dismiss) private var dismiss
    
    let userId: String
    
    let userName: String
    
    let userCourse: String
    
    
    
    @State private var postagensMural: [PostagemMural] = []
    
    @State private var anuncios: [Anuncio] = []
    
    @State private var loading = false
    
    @State private var errorMessage = ""
    
    @State private var abaSelecionada = 0
    
    
    
    @State private var editandoPostagem: PostagemMural?
    
    @State private var editandoAnuncio: Anuncio?
    
    @State private var confirmarExclusaoPostagem: PostagemMural?
    
    @State private var confirmarExclusaoAnuncio: Anuncio?
    
    
    
    var body: some View {
        
        NavigationStack {
            
            Group {
                
                if loading {
                    
                    ProgressView("Carregando publicacoes...")
                    
                } else {
                    
                    VStack(spacing: 0) {
                        
                        Picker("Categoria", selection: $abaSelecionada) {
                            
                            Text("Mural (\(postagensMural.count))").tag(0)
                            
                            Text("Classificados (\(anuncios.count))").tag(1)
                            
                        }
                        
                        .pickerStyle(.segmented)
                        
                        .padding()
                        
                        
                        
                        if abaSelecionada == 0 {
                            
                            if postagensMural.isEmpty {
                                
                                EmptyStateView(
                                    
                                    icon: "megaphone",
                                    
                                    title: "Nenhuma postagem no mural",
                                    
                                    message: "Suas postagens do mural aparecerao aqui."
                                    
                                )
                                
                            } else {
                                
                                List {
                                    
                                    ForEach(postagensMural) { postagem in
                                        
                                        VStack(alignment: .leading, spacing: 8) {
                                            
                                            HStack {
                                                
                                                Text(postagem.destino == "@geral" ? "@geral" : "@\(postagem.cursoDestino ?? "")")
                                                
                                                    .font(.caption.bold())
                                                
                                                    .foregroundStyle(.blue)
                                                
                                                Spacer()
                                                
                                                Text(formatarData(postagem.timestamp))
                                                
                                                    .font(.caption)
                                                
                                                    .foregroundStyle(.secondary)
                                                
                                            }
                                            
                                            Text(postagem.text)
                                            
                                                .font(.body)
                                            
                                            HStack {
                                                
                                                Button {
                                                    
                                                    editandoPostagem = postagem
                                                    
                                                } label: {
                                                    
                                                    Label("Editar", systemImage: "pencil")
                                                    
                                                        .font(.caption)
                                                    
                                                }
                                                
                                                .buttonStyle(.bordered)
                                                
                                                
                                                
                                                Button(role: .destructive) {
                                                    
                                                    confirmarExclusaoPostagem = postagem
                                                    
                                                } label: {
                                                    
                                                    Label("Excluir", systemImage: "trash")
                                                    
                                                        .font(.caption)
                                                    
                                                }
                                                
                                                .buttonStyle(.bordered)
                                                
                                            }
                                            
                                        }
                                        
                                        .padding(.vertical, 6)
                                        
                                    }
                                    
                                }
                                
                                .listStyle(.plain)
                                
                            }
                            
                        } else {
                            
                            if anuncios.isEmpty {
                                
                                EmptyStateView(
                                    
                                    icon: "cart",
                                    
                                    title: "Nenhum anuncio",
                                    
                                    message: "Seus anuncios dos classificados aparecerao aqui."
                                    
                                )
                                
                            } else {
                                
                                List {
                                    
                                    ForEach(anuncios) { anuncio in
                                        
                                        VStack(alignment: .leading, spacing: 8) {
                                            
                                            HStack {
                                                
                                                Text(anuncio.anuncioType.uppercased())
                                                
                                                    .font(.caption.bold())
                                                
                                                    .foregroundStyle(.blue)
                                                
                                                Spacer()
                                                
                                                Text(anuncio.destino == "@geral" ? "@geral" : "@\(anuncio.cursoDestino ?? "")")
                                                
                                                    .font(.caption)
                                                
                                                    .foregroundStyle(.secondary)
                                                
                                            }
                                            
                                            Text(anuncio.title).font(.headline)
                                            
                                            Text(anuncio.description)
                                            
                                                .foregroundStyle(.secondary)
                                            
                                            HStack {
                                                
                                                Button {
                                                    
                                                    editandoAnuncio = anuncio
                                                    
                                                } label: {
                                                    
                                                    Label("Editar", systemImage: "pencil")
                                                    
                                                        .font(.caption)
                                                    
                                                }
                                                
                                                .buttonStyle(.bordered)
                                                
                                                
                                                
                                                Button(role: .destructive) {
                                                    
                                                    confirmarExclusaoAnuncio = anuncio
                                                    
                                                } label: {
                                                    
                                                    Label("Excluir", systemImage: "trash")
                                                    
                                                        .font(.caption)
                                                    
                                                }
                                                
                                                .buttonStyle(.bordered)
                                                
                                            }
                                            
                                        }
                                        
                                        .padding(.vertical, 6)
                                        
                                    }
                                    
                                }
                                
                                .listStyle(.plain)
                                
                            }
                            
                        }
                        
                    }
                    
                }
                
            }
            
            .navigationTitle("Minhas publicacoes")
            
            .toolbar {
                
                ToolbarItem(placement: .cancellationAction) {
                    
                    Button("Fechar") { dismiss() }
                    
                }
                
            }
            
            .task { await carregar() }
            
            .refreshable { await carregar() }
            
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                
                Button("OK") { errorMessage = "" }
                
            } message: { Text(errorMessage) }
            
            
            
                .sheet(item: $editandoPostagem) { postagem in
                    
                    EditarPostagemView(postagem: postagem) {
                        
                        Task { await carregar() }
                        
                    }
                    
                }
            
                .sheet(item: $editandoAnuncio) { anuncio in
                    
                    EditarAnuncioView(anuncio: anuncio) {
                        
                        Task { await carregar() }
                        
                    }
                    
                }
            
            
            
                .alert("Excluir postagem do mural", isPresented: Binding(
                    
                    get: { confirmarExclusaoPostagem != nil },
                    
                    set: { if !$0 { confirmarExclusaoPostagem = nil } }
                    
                )) {
                    
                    Button("Cancelar", role: .cancel) { confirmarExclusaoPostagem = nil }
                    
                    Button("Excluir", role: .destructive) {
                        
                        if let p = confirmarExclusaoPostagem {
                            
                            Task { await excluirPostagem(p) }
                            
                        }
                        
                    }
                    
                } message: {
                    
                    Text("Tem certeza que deseja excluir esta postagem?")
                    
                }
            
                .alert("Excluir anuncio", isPresented: Binding(
                    
                    get: { confirmarExclusaoAnuncio != nil },
                    
                    set: { if !$0 { confirmarExclusaoAnuncio = nil } }
                    
                )) {
                    
                    Button("Cancelar", role: .cancel) { confirmarExclusaoAnuncio = nil }
                    
                    Button("Excluir", role: .destructive) {
                        
                        if let a = confirmarExclusaoAnuncio {
                            
                            Task { await excluirAnuncio(a) }
                            
                        }
                        
                    }
                    
                } message: {
                    
                    Text("Tem certeza que deseja excluir este anuncio?")
                    
                }
            
        }
        
    }
    
    
    
    private func carregar() async {
        
        guard !userId.isEmpty else {
            
            errorMessage = "Usuario nao identificado."
            
            return
            
        }
        
        loading = true
        
        defer { loading = false }
        
        
        
        do {
            
            let documentos = try await APIService.shared.buscarDocumentos()
            
            
            
            postagensMural = documentos.compactMap {
                
                guard case .postagem(let p) = $0 else { return nil }
                
                if let autorId = p.authorId, !autorId.isEmpty {
                    
                    return autorId == userId ? p : nil
                    
                }
                
                let mesmoNome = p.authorName.caseInsensitiveCompare(userName) == .orderedSame
                
                let mesmoCurso = p.authorCourse.caseInsensitiveCompare(userCourse) == .orderedSame
                
                return mesmoNome && mesmoCurso ? p : nil
                
            }
            
            .sorted { $0.timestamp > $1.timestamp }
            
            
            
            anuncios = documentos.compactMap {
                
                guard case .anuncio(let a) = $0 else { return nil }
                
                guard let sellerId = a.sellerId, !sellerId.isEmpty else { return nil }
                
                return sellerId == userId ? a : nil
                
            }
            
            .sorted { $0.createdAt > $1.createdAt }
            
            
            
            errorMessage = ""
            
        } catch {
            
            errorMessage = error.localizedDescription
            
        }
        
    }
    
    
    
    private func excluirPostagem(_ postagem: PostagemMural) async {
        
        guard let id = postagem.id, let rev = postagem.rev else {
            
            errorMessage = "Postagem sem id/revisao."
            
            confirmarExclusaoPostagem = nil
            
            return
            
        }
        
        do {
            
            try await APIService.shared.excluir(id: id, rev: rev)
            
            await carregar()
            
        } catch {
            
            errorMessage = error.localizedDescription
            
        }
        
        confirmarExclusaoPostagem = nil
        
    }
    
    
    
    private func excluirAnuncio(_ anuncio: Anuncio) async {
        
        guard let id = anuncio.id, let rev = anuncio.rev else {
            
            errorMessage = "Anuncio sem id/revisao."
            
            confirmarExclusaoAnuncio = nil
            
            return
            
        }
        
        do {
            
            try await APIService.shared.excluir(id: id, rev: rev)
            
            await carregar()
            
        } catch {
            
            errorMessage = error.localizedDescription
            
        }
        
        confirmarExclusaoAnuncio = nil
        
    }
    
    
    
    private func formatarData(_ iso: String) -> String {
        
        let isoFormatter = ISO8601DateFormatter()
        
        isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        
        var data = isoFormatter.date(from: iso)
        
        if data == nil {
            
            isoFormatter.formatOptions = [.withInternetDateTime]
            
            data = isoFormatter.date(from: iso)
            
        }
        
        guard let d = data else { return iso }
        
        let f = DateFormatter()
        
        f.dateFormat = "dd/MM/yyyy HH:mm"
        
        return f.string(from: d)
        
    }
    
}



