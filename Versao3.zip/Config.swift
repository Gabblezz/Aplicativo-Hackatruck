//
//  Config.swift
//  AppProjetoFinal
//
//  Created by Turma01 on 12/09/26.
//

import Foundation
import SwiftUI
import Combine

enum APIConfig {
    static let baseURL = "http://192.168.128.66:1880"
    static let documentosPath = "/api/documentos"
    static let usarDadosLocais = false
}

enum Cursos {
    static let lista = [
        "Administracao",
        "Ciencia da Computacao",
        "Ciencias Biologicas",
        "Ciencias Contabeis",
        "Ciencias Economicas",
        "Enfermagem",
        "Engenharia Agricola",
        "Engenharia Civil",
        "Farmacia",
        "Fisioterapia",
        "Geografia",
        "Historia",
        "Letras - Port./Espanhol",
        "Letras - Port./Ingles",
        "Matematica",
        "Medicina",
        "Odontologia",
        "Pedagogia",
        "Tecnologia em Design Educacional",
        "Outro / Setor Administrativo"
    ]
}
