//
//  APIService.swift
//  AppProjetoFinal
//
//  Created by Turma01 on 12/09/26.
//

import SwiftUI
import Foundation
import Combine

enum APIError: LocalizedError {
    case servidor
    case formatoInvalido
    case usuarioNaoEncontrado
    
    var errorDescription: String? {
        switch self {
        case .servidor: return "Nao foi possivel comunicar com a API."
        case .formatoInvalido: return "A resposta da API esta em formato invalido."
        case .usuarioNaoEncontrado: return "Usuario nao encontrado."
        }
    }
}

@MainActor
final class APIService: ObservableObject {
    static let shared = APIService()
    
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()
    
    private var documentosURL: URL {
        URL(string: APIConfig.baseURL + APIConfig.documentosPath)!
    }
    
    func buscarDocumentos() async throws -> [Documento] {
        let (data, response) = try await URLSession.shared.data(from: documentosURL)
        try validar(response, data: data)
        
        if let documentos = try? decoder.decode([Documento].self, from: data) {
            return documentos
        }
        if let lista = try? decoder.decode(ListaDocumentos.self, from: data) {
            return lista.documentos
        }
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            for chave in ["rows", "docs", "documentos"] {
                if let array = json[chave] as? [[String: Any]] {
                    var resultado: [Documento] = []
                    for item in array {
                        let alvo = (item["doc"] as? [String: Any]) ?? item
                        if let sub = try? JSONSerialization.data(withJSONObject: alvo),
                           let doc = try? decoder.decode(Documento.self, from: sub) {
                            resultado.append(doc)
                        }
                    }
                    if !resultado.isEmpty { return resultado }
                }
            }
        }
        throw APIError.formatoInvalido
    }
    
    @discardableResult
    func criar<T: Encodable>(_ documento: T) async throws -> String? {
        var request = URLRequest(url: documentosURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(documento)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validar(response, data: data)
        
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let id = json["id"] as? String {
            return id
        }
        return nil
    }
    
    @discardableResult
    func atualizar<T: Encodable>(_ documento: T) async throws -> String? {
        var request = URLRequest(url: documentosURL)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(documento)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validar(response, data: data)
        
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let id = json["id"] as? String {
            return id
        }
        return nil
    }
    
    func excluir(id: String, rev: String) async throws {
        var request = URLRequest(url: documentosURL)
        request.httpMethod = "DELETE"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(["_id": id, "_rev": rev])
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validar(response, data: data)
    }
    
    func buscarUsuario(id: String) async throws -> Usuario {
        guard let url = URL(string: APIConfig.baseURL + "/api/usuarios/\(id)") else {
            throw APIError.servidor
        }
        let (data, response) = try await URLSession.shared.data(from: url)
        try validar(response, data: data)
        return try decoder.decode(Usuario.self, from: data)
    }
    
    func buscarAvisos(usuarioId: String) async throws -> [Aviso] {
        guard let url = URL(string: APIConfig.baseURL + "/api/notificacoes/\(usuarioId)") else {
            throw APIError.servidor
        }
        let (data, response) = try await URLSession.shared.data(from: url)
        try validar(response, data: data)
        return try decoder.decode([Aviso].self, from: data)
    }
    
    func atualizarPreferencias(usuarioId: String, receberGeral: Bool, receberCursos: Bool) async throws {
        guard let url = URL(string: APIConfig.baseURL + "/api/usuarios/\(usuarioId)/notificacoes") else {
            throw APIError.servidor
        }
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(
            Notificacoes(receberGeral: receberGeral, receberCursos: receberCursos)
        )
        let (data, response) = try await URLSession.shared.data(for: request)
        try validar(response, data: data)
    }
    
    private func validar(_ response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else {
            throw APIError.servidor
        }
        guard 200..<300 ~= http.statusCode else {
            print("HTTP \(http.statusCode): \(String(data: data, encoding: .utf8) ?? "")")
            throw APIError.servidor
        }
    }
}
