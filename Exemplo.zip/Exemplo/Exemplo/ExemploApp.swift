//
//  ExemploApp.swift
//  Exemplo
//
//  Created by Turma01-8 on 10/09/26.
//

import SwiftUI

@main
struct ExemploApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
