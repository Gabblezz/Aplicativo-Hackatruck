//
//  ContentView.swift
//  Exemplo
//
//  Created by Turma01-8 on 10/09/26.
//

import SwiftUI

struct ContentView: View {
    @AppStorage("userRole") private var userRole: String = ""
    @AppStorage("isProfileCompleted") private var isProfileCompleted: Bool = false

    var body: some View {
        if userRole.isEmpty {
            RoleSelectionView(userRole: $userRole)
        } else if !isProfileCompleted {
            CompleteInfoView(isProfileCompleted: $isProfileCompleted)
        } else {
            MainDashboardView(userRole: $userRole, isProfileCompleted: $isProfileCompleted)
        }
    }
}

struct RoleSelectionView: View {
    @Binding var userRole: String
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Selecione seu perfil")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 20)
            
            roleButton(title: "Sou Aluno", role: "aluno", color: .blue)
            roleButton(title: "Sou Professor", role: "professor", color: .green)
            roleButton(title: "Sou Agente Universitário", role: "agente", color: .red)
        }
        .padding()
    }
    
    @ViewBuilder
    private func roleButton(title: String, role: String, color: Color) -> some View {
        Button(action: {
            withAnimation {
                userRole = role
            }
        }) {
            Text(title)
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(color)
                .cornerRadius(12)
                .padding(.horizontal, 20)
        }
    }
}

struct CompleteInfoView: View {
    @Binding var isProfileCompleted: Bool
    
    @State private var name: String = ""
    @State private var course: String = ""
    @State private var notifyAlerts: Bool = false
    @State private var notifyEvents: Bool = false
    @State private var notifyClassifieds: Bool = false
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Dados Pessoais")) {
                    TextField("Nome Completo", text: $name)
                    TextField("Curso / Setor", text: $course)
                }
                
                Section(header: Text("Preferências de Notificação")) {
                    Toggle("Quero receber notificações de avisos, editais e bolsas", isOn: $notifyAlerts)
                    Toggle("Quero receber notificações de eventos", isOn: $notifyEvents)
                    Toggle("Quero receber notificações de classificados", isOn: $notifyClassifieds)
                }
                
                Section {
                    Button(action: {
                        withAnimation {
                            isProfileCompleted = true
                        }
                    }) {
                        Text("Concluir Cadastro")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                    }
                    .listRowBackground(Color.blue)
                    .disabled(name.isEmpty || course.isEmpty)
                    .opacity(name.isEmpty || course.isEmpty ? 0.6 : 1.0)
                }
            }
            .navigationTitle("Complete seu Perfil")
        }
    }
}

struct MainDashboardView: View {
    @Binding var userRole: String
    @Binding var isProfileCompleted: Bool
    
    var body: some View {
        TabView {
            
            MuralGeralView()
                .tabItem {
                    Label("Mural Geral", systemImage: "megaphone.fill")
                }
            
            ClassificadosView()
                .tabItem {
                    Label("Classificados", systemImage: "cart.fill")
                }
            
            AreaExclusivaView(userRole: $userRole, isProfileCompleted: $isProfileCompleted)
                .tabItem {
                    Label("Para Você", systemImage: "person.text.rectangle.fill")
                }
        }
    }
}

struct MuralGeralView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 15) {
                Image(systemName: "globe")
                    .font(.system(size: 50))
                    .foregroundColor(.blue)
                    .padding(.top)
                
                Text("Avisos Gerais do Campus")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text("Esta tela é vista por alunos, professores e agentes universitários. Ideal para Achados e Perdidos, Eventos e Avisos de Infraestrutura.")
                    .font(.body)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 30)
                
                Spacer()
            }
            .navigationTitle("Mural Geral")
        }
    }
}

struct ClassificadosView: View {
    @State private var selectedTab = 0
    @State private var showingAddModal = false
    
    var body: some View {
        NavigationStack {
            VStack {
                Picker("Categorias", selection: $selectedTab) {
                    Text("Residências").tag(0)
                    Text("Materiais").tag(1)
                }
                .pickerStyle(.segmented)
                .padding()
                
                if selectedTab == 0 {
                    VStack {
                        Image(systemName: "house.fill")
                            .font(.largeTitle)
                            .foregroundColor(.blue)
                        Text("Lista de Casas e Quartos para Alugar")
                            .foregroundColor(.secondary)
                    }
                    .frame(maxHeight: .infinity)
                } else {
                    VStack {
                        Image(systemName: "book.fill")
                            .font(.largeTitle)
                            .foregroundColor(.green)
                        Text("Lista de Livros e Materiais de Matérias")
                            .foregroundColor(.secondary)
                    }
                    .frame(maxHeight: .infinity)
                }
            }
            .navigationTitle("Classificados")
            .toolbar {
                Button(action: { showingAddModal = true }) {
                    Image(systemName: "plus")
                }
            }
            .sheet(isPresented: $showingAddModal) {
                NovoAnuncioView()
            }
        }
    }
}

struct NovoAnuncioView: View {
    @Environment(\.dismiss) var dismiss
    
    @State private var typeSelection = "Residência"
    @State private var title = ""
    @State private var description = ""
    @State private var courseSelection = "Geral / Todos"
    
    let courses = ["Geral / Todos", "Engenharia", "Medicina", "Direito", "Ciência da Computação", "Administração"]
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Tipo do Anúncio")) {
                    Picker("Tipo", selection: $typeSelection) {
                        Text("Residência").tag("Residência")
                        Text("Material").tag("Material")
                    }
                    .pickerStyle(.segmented)
                }
                
                Section(header: Text("Informações")) {
                    TextField("Título do anúncio", text: $title)
                    TextField("Descrição detalhada", text: $description)
                }
                
                Section(header: Text("Curso Relacionado")) {
                    Picker("Selecione o Curso", selection: $courseSelection) {
                        ForEach(courses, id: \.self) { course in
                            Text(course)
                        }
                    }
                    .pickerStyle(.navigationLink)
                }
                
                Section {
                    Button("Publicar Anúncio") {
                        dismiss()
                    }
                    .frame(maxWidth: .infinity)
                    .foregroundColor(.blue)
                    .disabled(title.isEmpty || description.isEmpty)
                }
            }
            .navigationTitle("Criar Anúncio")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        dismiss()
                    }
                }
            }
        }
    }
}

struct AreaExclusivaView: View {
    @Binding var userRole: String
    @Binding var isProfileCompleted: Bool
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Área do \(roleFormattedName)")
                    .font(.title)
                    .fontWeight(.semibold)
                
                Text("Conteúdo exclusivo para o seu perfil.")
                    .foregroundColor(.secondary)
                
                Button("Alterar Perfil") {
                    withAnimation {
                        userRole = ""
                        isProfileCompleted = false
                    }
                }
                .foregroundColor(.red)
                .padding(.top, 40)
            }
            .navigationTitle("Area Restrita")
        }
    }
    
    private var roleFormattedName: String {
        switch userRole {
        case "aluno": return "Aluno"
        case "professor": return "Professor"
        case "agente": return "Agente Universitário"
        default: return "Usuário"
        }
    }
}

#Preview {
    ContentView()
}

