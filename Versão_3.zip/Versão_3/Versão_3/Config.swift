//
//  Config.swift
//  AppProjetoFinal
//
//  Created by Turma01 on 12/09/26.
//

import Foundation
import SwiftUI
import Combine

enum APIConfig {
    static let baseURL = "http://192.168.128.9:1880"
    static let documentosPath = "/api/documentos"
    static let usarDadosLocais = false
}

enum Cursos {
    static let lista = [
        "Administração",
        "Ciência da Computação",
        "Ciências Biologicas",
        "Ciências Contábeis",
        "Ciências Econômicas",
        "Enfermagem",
        "Engenharia Agrícola",
        "Engenharia Civil",
        "Farmácia",
        "Fisioterapia",
        "Geografia",
        "História",
        "Letras - Port./Espanhol",
        "Letras - Port./Inglês",
        "Matemática",
        "Medicina",
        "Odontologia",
        "Pedagogia",
        "Tecnologia em Design Educacional",
        "Outro / Setor Administrativo"
    ]
}
