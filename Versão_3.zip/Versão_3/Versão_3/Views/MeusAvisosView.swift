import SwiftUI
import Foundation
import Combine


struct MeusAvisosView: View {
    
    @Environment(\.dismiss) private var dismiss
    
    let usuarioId: String
    
    
    
    @State private var avisos: [Aviso] = []
    
    @State private var loading = false
    
    @State private var errorMessage = ""
    
    
    
    var body: some View {
        
        NavigationStack {
            
            Group {
                
                if loading {
                    
                    ProgressView("Carregando avisos...")
                    
                } else if avisos.isEmpty {
                    
                    EmptyStateView(icon: "bell", title: "Nenhum aviso", message: "Você ainda nao recebeu avisos.")
                    
                } else {
                    
                    List(avisos) { aviso in
                        
                        VStack(alignment: .leading, spacing: 8) {
                            
                            HStack {
                                
                                Image(systemName: aviso.destino == "@geral" ? "globe" : "graduationcap.fill")
                                
                                    .foregroundStyle(.blue)
                                
                                Text(aviso.titulo).font(.headline)
                                
                                Spacer()
                                
                                if !aviso.lida {
                                    
                                    Circle().fill(.blue).frame(width: 9, height: 9)
                                    
                                }
                                
                            }
                            
                            Text(aviso.mensagem)
                            
                            Text(aviso.destino == "@geral" ? "@geral" : "@\(aviso.curso ?? "")")
                            
                                .font(.caption)
                            
                                .foregroundStyle(.secondary)
                            
                        }
                        
                        .padding(.vertical, 6)
                        
                    }
                    
                }
                
            }
            
            .navigationTitle("Meus avisos")
            
            .toolbar {
                
                ToolbarItem(placement: .cancellationAction) {
                    
                    Button("Fechar") { dismiss() }
                    
                }
                
            }
            
            .task { await carregar() }
            
            .refreshable { await carregar() }
            
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                
                Button("OK") { errorMessage = "" }
                
            } message: { Text(errorMessage) }
            
        }
        
    }
    
    
    
    private func carregar() async {
        
        guard !usuarioId.isEmpty else { return }
        
        loading = true
        
        defer { loading = false }
        
        do {
            
            avisos = try await APIService.shared.buscarAvisos(usuarioId: usuarioId)
            
            errorMessage = ""
            
        } catch {
            if error.localizedDescription != "cancelled" {
                errorMessage = error.localizedDescription
            }
            
        }
        
    }
    
}


