import SwiftUI
import Foundation
import Combine

struct AreaExclusivaView: View {
    
    @Binding var userRole: String
    @Binding var isProfileCompleted: Bool
    @Binding var userId: String
    @Binding var userName: String
    @Binding var userCourse: String
    @Binding var receberGeral: Bool
    @Binding var receberCursos: Bool
    
    @State private var mostrarAvisos = false
    @State private var mostrarPublicacoes = false
    @State private var mostrarConfiguracoes = false
    
    @AppStorage("isDarkMode") private var isDarkMode = false
    
    var body: some View {
        
        NavigationStack {
            
            List {
                
                Section {
                    Label {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(userName.isEmpty ? userRole.capitalized : userName)
                                .font(.title3.bold())
                            Text(userCourse)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    } icon: {
                        Image(systemName: "person.crop.circle.fill")
                            .foregroundStyle(.blue)
                    }
                }
                
                Section("Minha conta") {
                    Button { mostrarAvisos = true } label: {
                        Label("Meus avisos", systemImage: "bell.badge.fill")
                    }
                    
                    Button { mostrarPublicacoes = true } label: {
                        Label("Minhas publicações", systemImage: "doc.text.fill")
                    }
                    
                    Button { mostrarConfiguracoes = true } label: {
                        Label("Configurações", systemImage: "gearshape.fill")
                    }
                }
                
                Section {
                    Button(role: .destructive) {
                        userRole = ""
                        isProfileCompleted = false
                        userId = ""
                        userName = ""
                        userCourse = ""
                    } label: {
                        Label("Sair e redefinir perfil", systemImage: "rectangle.portrait.and.arrow.right")
                    }
                }
            }
            .navigationTitle("Para Você")
        
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        withAnimation {
                            isDarkMode.toggle()
                        }
                    } label: {
                        Image(systemName: isDarkMode ? "moon.stars.fill" : "sun.max.fill")
                            .foregroundStyle(isDarkMode ? .yellow : .orange)
                    }
                }
            }
            .sheet(isPresented: $mostrarAvisos) {
                MeusAvisosView(usuarioId: userId)
            }
            .sheet(isPresented: $mostrarPublicacoes) {
                MinhasPublicacoesView(
                    userId: userId,
                    userName: userName,
                    userCourse: userCourse
                )
            }
            .sheet(isPresented: $mostrarConfiguracoes) {
                ConfiguracoesView(
                    usuarioId: userId,
                    receberGeral: $receberGeral,
                    receberCursos: $receberCursos
                )
            }
            
            .preferredColorScheme(isDarkMode ? .dark : .light)
        }
    }
}

