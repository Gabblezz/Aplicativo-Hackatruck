//
//  MainDashboardView.swift
//  AppProjetoFinal
//
//  Created by Turma01 on 12/09/26.
//

import SwiftUI
import Foundation
import Combine


struct MainDashboardView: View {
    
    @Binding var userRole: String
    
    @Binding var isProfileCompleted: Bool
    
    @Binding var userId: String
    
    @Binding var userName: String
    
    @Binding var userCourse: String
    
    @Binding var receberGeral: Bool
    
    @Binding var receberCursos: Bool
    
    
    
    var body: some View {
        
        TabView {
            
            MuralGeralView(
                
                userRole: userRole,
                
                userId: userId,
                
                userName: userName,
                
                userCourse: userCourse
                
            )
            
            .tabItem { Label("Mural", systemImage: "megaphone.fill") }
            
            
            
            ClassificadosView(userId: userId)
            
                .tabItem { Label("Classificados", systemImage: "cart.fill") }
            
            
            
            AreaExclusivaView(
                
                userRole: $userRole,
                
                isProfileCompleted: $isProfileCompleted,
                
                userId: $userId,
                
                userName: $userName,
                
                userCourse: $userCourse,
                
                receberGeral: $receberGeral,
                
                receberCursos: $receberCursos
                
            )
            
            .tabItem { Label("Para você", systemImage: "person.crop.circle.fill") }
            
        }
        
    }
    
}


