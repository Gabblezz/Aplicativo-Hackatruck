//
//  RoleSelectionView.swift
//  AppProjetoFinal
//
//  Created by Turma01 on 12/09/26.
//
import SwiftUI
import Foundation
import Combine

struct RoleSelectionView: View {
    
    @Binding var userRole: String
    @State private var isAnimating = false
    
    var body: some View {
        
        NavigationStack {
            ZStack{
                MeshGradient(
                    width: 4,
                    height: 4,
                    points: [
                        // Top row
                        [0.5, 1.0], [0.3, 0.0], [0.6,0.0], [1.0, 0.0],
                        // Middle row (Animating X and Y to create fluid shift)
                        [-0.1, 1.5], [isAnimating ? 0.5 : 0.6, isAnimating ? 0.3 : 0.6], [1.1, 0.5], [isAnimating ? 0.9 : 0.7, isAnimating ? 1.0 : 0.6],
                        
                        [0.0,0.7],[isAnimating ? 0.3 : 0.5, isAnimating ? 0.4: 0.8],[isAnimating ? 0.51 : 0.61, isAnimating ? 0.7 : 0.75],[1.0, 0.6],
                        // Bottom row
                        [-1.0, 1.0], [isAnimating ? 0.5 : 0.7, 1.0], [isAnimating ? 0.7 : 1.0, 1.0]
                    ],
                    colors: [
                        .white, .blue, .blue, .indigo,
                        .teal, .blue, .blue, .blue,
                        .indigo, .blue, .teal, .indigo,
                        .clear, .indigo, .indigo, .indigo
                    ]
                )
                .ignoresSafeArea()
                .onAppear {
                    withAnimation(.easeInOut(duration: 5.0).repeatForever(autoreverses: true)) {
                        isAnimating.toggle()
                    }
                }
                
                VStack(spacing: 24) {
                    
                    Image("Image")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 175, height: 150)
                    
                    Text("UnioLink")
                    
                        .font(.largeTitle.bold())
                    
                        .multilineTextAlignment(.center)
                    
                    
                    
                    Text("Selecione como você vai usar o aplicativo")
                    
                        .foregroundStyle(.secondary)
                    
                        .multilineTextAlignment(.center)
                    
                    roleButton("Sou Aluno", role: "aluno", color: .indigo, icon: "graduationcap.fill")
                    
                    roleButton("Sou Professor", role: "professor", color: .cyan, icon: "person.fill")
                    
                    roleButton("Sou Agente Universitário", role: "agente", color: .blue, icon: "building.2.fill")
                    
                }
                
                .padding(24)
                
                .navigationTitle("Bem-vindo")
            }
            
        }
        
    }
    
    
    private func roleButton(_ title: String, role: String, color: Color, icon: String) -> some View {
        Button {
            userRole = role
        } label: {
            Label(title, systemImage: icon)
                .font(.headline)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(color, in: RoundedRectangle(cornerRadius: 22))
                .shadow(color: Color.black.opacity(0.8), radius: 8, x: 0, y: 8)
        }
    }

    
}



