import SwiftUI
import Foundation
import Combine


struct ConfiguracoesView: View {
    
    @Environment(\.dismiss) private var dismiss
    
    let usuarioId: String
    
    @Binding var receberGeral: Bool
    
    @Binding var receberCursos: Bool
    
    @State private var salvando = false
    
    @State private var mensagem = ""
    
    @State private var erro = ""
    
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Section("Notificações") {
                    
                    Toggle("Receber avisos de @geral", isOn: $receberGeral)
                    
                    Toggle("Receber avisos de cursos", isOn: $receberCursos)
                    
                }
                
                Section {
                    
                    Button {
                        
                        Task { await salvar() }
                        
                    } label: {
                        
                        HStack {
                            
                            Spacer()
                            
                            if salvando { ProgressView() }
                            
                            else { Text("Salvar configurações").bold() }
                            
                            Spacer()
                            
                        }
                        
                    }
                    
                    .disabled(salvando || usuarioId.isEmpty)
                    
                }
                
                
                
                if !mensagem.isEmpty {
                    
                    Section {
                        
                        Label(mensagem, systemImage: "checkmark.circle.fill")
                        
                            .foregroundStyle(.green)
                        
                    }
                    
                }
                
            }
            
            .navigationTitle("Configurações")
            
            .toolbar {
                
                ToolbarItem(placement: .cancellationAction) {
                    
                    Button("Fechar") { dismiss() }
                    
                }
                
            }
            
            .alert("Erro", isPresented: Binding(get: { !erro.isEmpty }, set: { if !$0 { erro = "" } })) {
                
                Button("OK") { erro = "" }
                
            } message: { Text(erro) }
            
        }
        
    }
    
    private func salvar() async {
        
        salvando = true
        
        mensagem = ""
        
        defer { salvando = false }
        
        do {
            
            if !APIConfig.usarDadosLocais {
                
                try await APIService.shared.atualizarPreferencias(
                    
                    usuarioId: usuarioId,
                    
                    receberGeral: receberGeral,
                    
                    receberCursos: receberCursos
                    
                )
                
            }
            
            mensagem = "Configuracoes salvas com sucesso."
            
        } catch {
            
            erro = error.localizedDescription
            
        }
        
    }
    
}


