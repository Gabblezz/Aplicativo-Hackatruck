//
//  CompleteInfoView.swift
//  AppProjetoFinal
//
//  Created by Turma01 on 12/09/26.
//

import SwiftUI
import Foundation
import Combine


struct CompleteInfoView: View {
    
    @Binding var userRole: String
    
    @Binding var isProfileCompleted: Bool
    
    @Binding var userId: String
    
    @Binding var userName: String
    
    @Binding var userCourse: String
    
    @Binding var receberGeral: Bool
    
    @Binding var receberCursos: Bool
    
    
    
    @State private var name = ""
    
    @State private var course = ""
    
    @State private var saving = false
    
    @State private var errorMessage = ""
    
    
    
    private let cursos = Cursos.lista
    
    
    
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Section("Dados pessoais") {
                    
                    TextField("Nome completo", text: $name)
                    
                    Picker("Curso / setor", selection: $course) {
                        
                        Text("Selecione uma opção").tag("")
                        
                        ForEach(cursos, id: \.self) { Text($0).tag($0) }
                        
                    }
                    
                }
                
                
                
                Section("Preferencias de notificação") {
                    
                    Toggle("Receber avisos de @geral", isOn: $receberGeral)
                    
                    Toggle("Receber avisos do meu curso", isOn: $receberCursos)
                    
                }
                
                
                
                Button {
                    
                    Task { await salvar() }
                    
                } label: {
                    
                    HStack {
                        
                        Spacer()
                        
                        if saving { ProgressView().tint(.white) }
                        
                        else { Text("Concluir cadastro").bold() }
                        
                        Spacer()
                        
                    }
                    
                }
                
                .foregroundStyle(.white)
                
                .listRowBackground(Color.blue)
                
                .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || course.isEmpty || saving)
                
            }
            
            .navigationTitle("Complete seu perfil")
            
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                
                Button("OK") { errorMessage = "" }
                
            } message: { Text(errorMessage) }
            
        }
        
    }
    
    
    
    private func salvar() async {
        
        saving = true
        
        defer { saving = false }
        
        
        
        let idLocal = UUID().uuidString
        
        let nome = name.trimmingCharacters(in: .whitespacesAndNewlines)
        
        let usuario = Usuario(
            
            id: idLocal,
            
            rev: nil,
            
            tipo: "usuario",
            
            nome: nome,
            
            perfil: userRole,
            
            curso: course,
            
            notificacoes: Notificacoes(receberGeral: receberGeral, receberCursos: receberCursos)
            
        )
        
        
        
        do {
            
            var idFinal = idLocal
            
            if !APIConfig.usarDadosLocais {
                
                if let idServidor = try await APIService.shared.criar(usuario) {
                    
                    idFinal = idServidor
                    
                }
                
            }
            
            userId = idFinal
            
            userName = nome
            
            userCourse = course
            
            isProfileCompleted = true
            
        } catch {
            if error.localizedDescription != "cancelled" {
                errorMessage = error.localizedDescription
            }
            
        }
        
    }
    
}

