import SwiftUI
import Foundation
import Combine


struct ClassificadosView: View {
    
    let userId: String
    
    
    
    @State private var anuncios: [Anuncio] = []
    
    @State private var showingNew = false
    
    @State private var search = ""
    
    @State private var errorMessage = ""
    
    
    
    private var filtrados: [Anuncio] {
        
        guard !search.isEmpty else { return anuncios }
        
        return anuncios.filter {
            
            $0.title.localizedCaseInsensitiveContains(search) ||
            
            $0.description.localizedCaseInsensitiveContains(search)
            
        }
        
    }
    
    
    
    var body: some View {
        
        NavigationStack {
            
            Group {
                
                if filtrados.isEmpty {
                    
                    EmptyStateView(icon: "cart", title: "Nenhum anúncio", message: "Publique materiais, quartos ou serviços.")
                    
                } else {
                    
                    List(filtrados) { anuncio in
                        
                        AnuncioRow(anuncio: anuncio)
                        
                    }
                    
                    .listStyle(.plain)
                    
                    .refreshable { await carregar() }
                    
                }
                
            }
            
            .navigationTitle("Classificados")
            
            .searchable(text: $search, prompt: "Buscar anúncio")
            
            .toolbar {
                
                ToolbarItem(placement: .topBarTrailing) {
                    
                    Button { showingNew = true } label: {
                        
                        Image(systemName: "plus.circle.fill")
                        
                    }
                    
                }
                
            }
            
            .sheet(isPresented: $showingNew) {
                
                NewAnuncioView(userId: userId) { Task { await carregar() } }
                
            }
            
            .task { await carregar() }
            
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                
                Button("OK") { errorMessage = "" }
                
            } message: { Text(errorMessage) }
            
        }
        
    }
    
    
    
    private func carregar() async {
        
        do {
            
            anuncios = try await APIService.shared.buscarDocumentos().compactMap {
                
                if case .anuncio(let anuncio) = $0 { return anuncio }
                
                return nil
                
            }
            
            errorMessage = ""
            
        } catch {
            
            errorMessage = error.localizedDescription
            
        }
        
    }
    
}


