import SwiftUI
import Foundation
import Combine

struct NewAnuncioView: View {
    
    @Environment(\.dismiss) private var dismiss
    
    let userId: String
    
    let onSaved: () -> Void
    
    
    
    @State private var type = "Material"
    
    @State private var title = ""
    
    @State private var description = ""
    
    @State private var destino = "@geral"
    
    @State private var cursoEscolhido = ""
    
    @State private var saving = false
    
    @State private var errorMessage = ""
    
    
    
    private let categorias = ["Material", "Residencia", "Serviço", "Outro"]
    
    private let cursos = Cursos.lista
    
    
    
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Picker("Categoria", selection: $type) {
                    
                    ForEach(categorias, id: \.self) { Text($0) }
                    
                }
                
                
                
                Section("Destino do anuncio") {
                    
                    Picker("Notificar", selection: $destino) {
                        
                        Text("Todos (@geral)").tag("@geral")
                        
                        Text("Curso especifico (@curso)").tag("@curso")
                        
                    }
                    
                    .pickerStyle(.segmented)
                    
                    
                    
                    if destino == "@curso" {
                        
                        Picker("Escolha o curso", selection: $cursoEscolhido) {
                            
                            Text("Selecione um curso").tag("")
                            
                            ForEach(cursos, id: \.self) { Text($0).tag($0) }
                            
                        }
                        
                    }
                    
                }
                
                
                
                Section("Detalhes") {
                    
                    TextField("Titulo", text: $title)
                    
                    TextEditor(text: $description)
                    
                        .frame(minHeight: 120)
                    
                }
                
                
                
                Button {
                    
                    Task { await salvar() }
                    
                } label: {
                    
                    HStack {
                        
                        Spacer()
                        
                        if saving { ProgressView() } else { Text("Publicar anuncio").bold() }
                        
                        Spacer()
                        
                    }
                    
                }
                
                .disabled(!podeSalvar || saving)
                
            }
            
            .navigationTitle("Novo anuncio")
            
            .toolbar {
                
                ToolbarItem(placement: .cancellationAction) {
                    
                    Button("Cancelar") { dismiss() }
                    
                }
                
            }
            
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                
                Button("OK") { errorMessage = "" }
                
            } message: { Text(errorMessage) }
            
        }
        
    }
    
    
    
    private var podeSalvar: Bool {
        
        if title.isEmpty || description.isEmpty { return false }
        
        if destino == "@curso" && cursoEscolhido.isEmpty { return false }
        
        return true
        
    }
    
    
    
    private func salvar() async {
        
        saving = true
        
        defer { saving = false }
        
        
        
        let cursoFinal = destino == "@geral" ? "Geral / Todos" : cursoEscolhido
        
        
        
        let anuncio = Anuncio(
            
            id: nil,
            
            rev: nil,
            
            tipo: "anuncio",
            
            anuncioType: type,
            
            title: title,
            
            description: description,
            
            course: cursoFinal,
            
            sellerId: userId.isEmpty ? nil : userId,
            
            createdAt: ISO8601DateFormatter().string(from: Date()),
            
            destino: destino,
            
            cursoDestino: destino == "@geral" ? nil : cursoEscolhido
            
        )
        
        
        
        do {
            
            try await APIService.shared.criar(anuncio)
            
            onSaved()
            
            dismiss()
            
        } catch {
            
            errorMessage = error.localizedDescription
            
        }
        
    }
    
}

