//
//  Models.swift
//  AppProjetoFinal
//
//  Created by Turma01 on 12/09/26.
//

import Foundation

struct Notificacoes: Codable {
    var receberGeral: Bool
    var receberCursos: Bool
}

struct Usuario: Codable, Identifiable {
    var id: String?
    var rev: String?
    let tipo: String
    var nome: String
    var perfil: String
    var curso: String
    var notificacoes: Notificacoes
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case rev = "_rev"
        case tipo, nome, perfil, curso, notificacoes
    }
}

struct PostagemMural: Codable, Identifiable {
    var id: String?
    var rev: String?
    let tipo: String
    var authorId: String?
    var authorName: String
    var authorRole: String
    var authorCourse: String
    var text: String
    var timestamp: String
    var destino: String?
    var cursoDestino: String?
    var imageName: String? // Campo opcional para o nome do asset (ex: "Cipet" ou "HackAREAC")
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case rev = "_rev"
        case tipo, authorId, authorName, authorRole, authorCourse, text, timestamp
        case destino, cursoDestino, imageName
    }
    
    var identificador: String { id ?? UUID().uuidString }
}

struct Anuncio: Codable, Identifiable {
    var id: String?
    var rev: String?
    let tipo: String
    var anuncioType: String
    var title: String
    var description: String
    var course: String
    var sellerId: String?
    var createdAt: String
    var destino: String?
    var cursoDestino: String?
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case rev = "_rev"
        case tipo, anuncioType, title, description, course, sellerId, createdAt
        case destino, cursoDestino
    }
    
    var identificador: String { id ?? UUID().uuidString }
}

struct Aviso: Codable, Identifiable {
    let id: String
    let tipo: String
    let usuarioId: String?
    let postagemId: String?
    let destino: String?
    let titulo: String
    let mensagem: String
    let curso: String?
    let criadaEm: String
    var lida: Bool
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case tipo, usuarioId, postagemId, destino, titulo, mensagem, curso
        case criadaEm, lida
    }
}

struct ListaDocumentos: Codable {
    let documentos: [Documento]
}

private struct TipoDocumento: Codable {
    let tipo: String
}

enum Documento: Codable {
    case usuario(Usuario)
    case postagem(PostagemMural)
    case anuncio(Anuncio)
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let tipo = try container.decode(TipoDocumento.self).tipo
        
        switch tipo {
        case "usuario": self = .usuario(try container.decode(Usuario.self))
        case "postagem": self = .postagem(try container.decode(PostagemMural.self))
        case "anuncio": self = .anuncio(try container.decode(Anuncio.self))
        default:
            throw DecodingError.dataCorruptedError(
                in: container,
                debugDescription: "Tipo de documento invalido: \(tipo)"
            )
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .usuario(let valor): try container.encode(valor)
        case .postagem(let valor): try container.encode(valor)
        case .anuncio(let valor): try container.encode(valor)
        }
    }
}
