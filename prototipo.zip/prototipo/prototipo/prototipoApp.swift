//
//  AppProjetoFinalApp.swift
//  AppProjetoFinal
//
//  Created by Turma01 on 12/09/26.
//

import SwiftUI

@main
struct prototipoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


