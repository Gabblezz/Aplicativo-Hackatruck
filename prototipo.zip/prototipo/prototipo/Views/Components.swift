import SwiftUI
import Foundation
import Combine



struct PostCard: View {
    let postagem: PostagemMural
    
    private var inicialAutor: String {
        let partes = postagem.authorName.split(separator: " ")
        if partes.count >= 2, let primeira = partes.first?.first, let segunda = partes.last?.first {
            return "\(primeira)\(segunda)".uppercased()
        } else if let primeira = postagem.authorName.first {
            return String(primeira).uppercased()
        }
        return "U"
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Cabeçalho (Iniciais + Autor + Tag)
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color.purple.opacity(0.15))
                        .frame(width: 42, height: 42)
                    
                    Text(inicialAutor)
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(.purple)
                }
                
                VStack(alignment: .leading, spacing: 2) {
                    HStack {
                        Text(postagem.authorName)
                            .font(.subheadline.bold())
                            .foregroundStyle(.primary)
                        
                        Text("• \(postagem.authorRole)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    
                    Text(postagem.authorCourse)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                
                Spacer()
                
                if let destino = postagem.destino {
                    Text(destino == "@geral" ? "@geral" : "@\(postagem.cursoDestino ?? "")")
                        .font(.caption2.bold())
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.purple.opacity(0.1), in: Capsule())
                        .foregroundStyle(.purple)
                }
            }
            
            Divider()
            
            // Texto do Post
            Text(postagem.text)
                .font(.body)
                .lineSpacing(3)
                .foregroundStyle(.primary)
            
            // Imagem Estática (Protótipo Teams/Twitter)
            if let imageName = postagem.imageName, !imageName.isEmpty {
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(.systemGray4), lineWidth: 0.5)
                    )
            }
            
            // Rodapé de Ações
            HStack(spacing: 24) {
                Button {} label: {
                    Label("Responder", systemImage: "bubble.left")
                        .font(.caption.bold())
                }
                
                Button {} label: {
                    Label("Reagir", systemImage: "face.smiling")
                        .font(.caption)
                }
                
                Spacer()
                
                Button {} label: {
                    Image(systemName: "square.and.arrow.up")
                        .font(.caption)
                }
            }
            .foregroundStyle(.secondary)
            .padding(.top, 4)
        }
        .padding(14)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color(.systemGray5), lineWidth: 1)
        )
        .shadow(color: Color.black.opacity(0.03), radius: 6, x: 0, y: 3)
    }
}


struct AnuncioRow: View {
    let anuncio: Anuncio
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(anuncio.anuncioType.uppercased())
                    .font(.caption2.bold())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(Color.blue.opacity(0.1), in: Capsule())
                    .foregroundStyle(.blue)
                
                Spacer()
                
                if let destino = anuncio.destino {
                    Text(destino == "@geral" ? "@geral" : "@\(anuncio.cursoDestino ?? "")")
                        .font(.caption2.bold())
                        .foregroundStyle(.secondary)
                }
            }
            
            Text(anuncio.title)
                .font(.headline)
                .foregroundStyle(.primary)
            
            Text(anuncio.description)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .lineLimit(3)
        }
        .padding(14)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color(.systemGray5), lineWidth: 1)
        )
        .padding(.vertical, 4)
    }
}


struct EmptyStateView: View {
    let icon: String
    let title: String
    let message: String
    
    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 48))
                .foregroundStyle(.blue)
            Text(title).font(.title3.bold())
            Text(message)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 35)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
