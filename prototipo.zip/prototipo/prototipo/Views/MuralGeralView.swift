import SwiftUI
import Foundation
import Combine

// Removido o import duplicado do SwiftUI

struct MuralGeralView: View {
    let userRole: String
    let userId: String
    let userName: String
    let userCourse: String
    
    @State private var postagens: [PostagemMural] = []
    @State private var showingNewPost = false
    @State private var loading = false
    @State private var errorMessage = ""
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                Group {
                    if loading {
                        ProgressView("Carregando mural...")
                    } else if postagens.isEmpty {
                        EmptyStateView(
                            icon: "megaphone",
                            title: "Nenhuma postagem",
                            message: "Seja o primeiro a publicar um aviso."
                        )
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 14) {
                                ForEach(postagens) { postagem in
                                    PostCard(postagem: postagem)
                                }
                            }
                            .padding(.horizontal)
                            .padding(.top, 10)
                            .padding(.bottom, 80) // Espaço para o botão flutuante não cobrir o último post
                        }
                        .background(Color(.systemGroupedBackground))
                        .refreshable { await carregar() }
                    }
                }
                
                // Botão Flutuante (FAB) do Teams no canto inferior direito
                Button {
                    showingNewPost = true
                } label: {
                    Image(systemName: "square.and.pencil")
                        .font(.title2.bold())
                        .foregroundStyle(.white)
                        .frame(width: 56, height: 56)
                        .background(Color.blue, in: Circle())
                        .shadow(color: Color.blue.opacity(0.4), radius: 8, x: 0, y: 4)
                }
                .padding(.trailing, 20)
                .padding(.bottom, 20)
            }
            .navigationTitle("Mural Geral")
            .sheet(isPresented: $showingNewPost) {
                NewPostView(
                    userRole: userRole,
                    userId: userId,
                    userName: userName,
                    userCourse: userCourse
                ) {
                    Task { await carregar() }
                }
            }
            .task { await carregar() }
            .alert("Erro", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                Button("OK") { errorMessage = "" }
            } message: { Text(errorMessage) }
        }
    }
    
    // O @MainActor garante que as mudanças em @State rodem na Thread Principal com segurança
    @MainActor
    private func carregar() async {
        loading = true
        defer { loading = false }
        
        // Se estiver usando dados locais ou quiser testar o protótipo:
        if APIConfig.usarDadosLocais {
            postagens = [
                PostagemMural(
                    id: "1",
                    tipo: "postagem",
                    authorName: "Jaqueline Faino",
                    authorRole: "Aluna",
                    authorCourse: "Ciência da Computação",
                    text: "Pessoal, convido todos para a palestra sobre Robótica na Ciência da Computação! Ocorrerá no Bloco A, Sala A115 às 13:30.",
                    // Nota: Certifique-se de que a propriedade 'timestamp' em PostagemMural aceita String.
                    // Se ela esperar um tipo 'Date', mude para: timestamp: Date()
                    timestamp: ISO8601DateFormatter().string(from: Date()),
                    destino: "@curso",
                    cursoDestino: "Ciência da Computação",
                    imageName: "Cipet"
                ),
                PostagemMural(
                    id: "2",
                    tipo: "postagem",
                    authorName: "Marcio Seiji Oyamada",
                    authorRole: "Professor",
                    authorCourse: "Ciência da Computação",
                    text: "Estão abertas as inscrições para o Hackathon AREAC! O tema deste ano será Agricultura Familiar. Monte sua equipe!",
                    timestamp: ISO8601DateFormatter().string(from: Date()),
                    destino: "@geral",
                    cursoDestino: nil,
                    imageName: "HackAREAC"
                )
            ]
            return
        }
        
        do {
            postagens = try await APIService.shared.buscarDocumentos().compactMap {
                if case .postagem(let postagem) = $0 { return postagem }
                return nil
            }
            .sorted { $0.timestamp > $1.timestamp }
            errorMessage = ""
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

